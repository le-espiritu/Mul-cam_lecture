package oop.basic;

public class ForExam01 {
	public static void main(String[] args) {

		MyMethodUtil obj = new MyMethodUtil();
		obj.printNumber();

	}
}
