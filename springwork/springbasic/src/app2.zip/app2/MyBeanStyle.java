package app2;

public interface MyBeanStyle {
	 void testHello(String name) ;
}
