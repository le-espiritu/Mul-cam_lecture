package app2;

public class MyBeanStyleA implements MyBeanStyle {
	public void testHello(String name) {
		System.out.println("안녕하세요...."+name);
	}
}
