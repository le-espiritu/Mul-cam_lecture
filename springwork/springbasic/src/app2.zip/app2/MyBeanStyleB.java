package app2;

public class MyBeanStyleB implements MyBeanStyle {
	public void testHello(String name) {
		System.out.println("hello...."+name);
	}
}
